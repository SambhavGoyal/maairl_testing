############################## Shared Space Model discrete ##########################
import numpy as np
from multiagent.core import World, Agent, Landmark
from multiagent.scenario import BaseScenario

import math
import random
### 0 is ped (adversary); agent 1 is cyclist  and same landmarks 
# add agent max for states (do not ad for x,y), just for speed and theta 
# state p_pos (x,y), added: p_vel_abs, p_theta 
class Scenario(BaseScenario):
    def make_world(self):
        world = World()
        # set any world properties first
        world.dim_c = 2 #R: all scenarios put this 2, do not why ################# may need to put it zero or my it used later in action 
        num_agents = 2 ## include all with adversary 
        num_adversaries = 1
        num_landmarks = 2
        # add agents
        world.agents = [Agent() for i in range(num_agents)]
        for i, agent in enumerate(world.agents):
            agent.name = 'agent %d' % i
            agent.collide = False #R: False
            agent.silent = True #R: cannot send communication signals 
            agent.max_speed = 7.96 #R: for headon: cyclist 7.96 m/s; 10.1
            agent.max_theta = math.pi 
            agent.max_acc = 10.0 #R: m/s2  ### not sure if we need to modify the action output from model since it wuld effect its variance 
            agent.max_deltatheta = 1.8 #R: rad/s; headone: -1.83 to 2.8
            #agent.state.p_theta = np.zeros(1) #R: state var: put them in core 
            #agent.state.p_vel_abs = np.zeros(1) #R: state var
            if i < num_adversaries: # for ped 
                agent.adversary = True
                #agent.initial_mass = 5.0
                agent.max_speed = 5.93 # ped R: m/sfor headon: ped: 5.93 m/s; crossing: 6.66
                agent.max_theta = math.pi 
                agent.max_acc = 5.0 #ped R: m/s2
                agent.max_deltatheta = 1.8 #R: rad/s
            else:
                agent.adversary = False
        # add landmarks
        world.landmarks = [Landmark() for i in range(num_landmarks)]
        for i, landmark in enumerate(world.landmarks):
            landmark.name = 'landmark %d' % i #R: 0 is ped, 1 for bike 
            landmark.collide = False
            landmark.movable = False
        # make initial conditions
        self.reset_world(world)
        return world

    def reset_world(self, world):
        # random properties for landmarks
        for i, landmark in enumerate(world.landmarks):
            #landmark.color = np.array([0.1, 0.1, 0.1])
            #landmark.color[i + 1] += 0.8
            landmark.index = i
        # set goal landmark (simple psh is single landmark, so modify it)
        #goal = np.random.choice(world.landmarks) #R: can make final position is landmark for each case 
        for i, agent in enumerate(world.agents):
            #agent.goal_a = goal
            agent.goal_a = world.landmarks[i] #0 for ped, 1 for bike 
            #agent.color = np.array([0.25, 0.25, 0.25])
            #if agent.adversary:
                #agent.color = np.array([0.75, 0.25, 0.25])
            #else:
                #j = goal.index
                #agent.color[j + 1] += 0.5
        
        # put data of all traj ped and cyclist of sahred space in a format to select random from it for initializations,
        # this should contain ped: initials of : X,Y,theta,V,Xtarget, Ytarget; Cyclist: intials of X,Y,theta,V,Xtarget, Ytarget, Time total of each till done occurs
        # update previous infos in each agent
        
        #### activate which case are you working with headon or corssing: data for initilization
        #headon
        array_initials =np.loadtxt('/home/bitsafs/Rushdi/RL_multiagent_R/RL_multiagent/rushdi_Final__MA/headon/Evn_InitialS_and_goal/Headon_array_initial_target.txt')
        # crossing 
        #array_initials =np.loadtxt('/home/bitsafs/Rushdi/RL_multiagent_R/RL_multiagent/rushdi_Final__MA/crossing/Evn_InitialS_and_goal/crossing_array_initial_target.txt')

        rn_len = len(array_initials) #229 for head on 
        rn = random.randint(0,rn_len-1)
        #rn = 0 # just do debugging 
         
        for i, agent in enumerate(world.agents):
            if i == 0: #ped
                agent.state.p_pos = np.zeros(world.dim_p) #np.random.uniform(-1, +1, world.dim_p)
                agent.state.p_pos[0] = array_initials[rn][0]
                agent.state.p_pos[1] = array_initials[rn][1]
                
                agent.state.p_theta = np.zeros(1) 
                agent.state.p_theta[0] =  array_initials[rn][2] 
                
                agent.state.p_vel = np.ones(1)
                agent.state.p_vel[0] = array_initials[rn][3]
                agent.time_to_done = array_initials[rn][12]
                agent.traj_id = rn+1
                
            if i == 1: #bike
                agent.state.p_pos = np.zeros(world.dim_p) #np.random.uniform(-1, +1, world.dim_p)
                agent.state.p_pos[0] = array_initials[rn][6]
                agent.state.p_pos[1] = array_initials[rn][7]
                
                agent.state.p_theta = np.zeros(1) 
                agent.state.p_theta[0] =  array_initials[rn][8] 
                
                agent.state.p_vel = np.ones(1)
                agent.state.p_vel[0] = array_initials[rn][9]
                agent.time_to_done = array_initials[rn][12]
                agent.traj_id = rn+1
                 
        for i, landmark in enumerate(world.landmarks):
            if  i ==0:
                landmark.state.p_pos = np.ones(world.dim_p)
                landmark.state.p_pos[0] = array_initials[rn][4]
                landmark.state.p_pos[1] = array_initials[rn][5]
            if  i ==1:
                landmark.state.p_pos = np.ones(world.dim_p)
                landmark.state.p_pos[0] = array_initials[rn][10]
                landmark.state.p_pos[1] = array_initials[rn][11]
    
        
        # # set random initial states (R: need to modify them later in case will se them to generate traj)
        # for agent in world.agents: ##R: make restart based on initial traj points 
        #     agent.state.p_pos = np.zeros(world.dim_p) #np.random.uniform(-1, +1, world.dim_p)
        #     agent.state.p_vel = np.ones(1)#np.zeros(world.dim_p)
        #     #agent.state.c = np.zeros(world.dim_c)
        #     agent.state.p_theta = np.zeros(1) #R: state var
        #     #agent.state.p_vel_abs =  np.zeros(1) #R: state var 
         

    def reward(self, agent, world):
        # Agents are rewarded based on minimum agent distance to each landmark
        return self.adversary_reward(agent, world) if agent.adversary else self.agent_reward(agent, world)

    def agent_reward(self, agent, world): #R: bike reward
        # the distance to the goal #R: set reward from discriminator 
        return -np.sqrt(np.sum(np.square(agent.state.p_pos - agent.goal_a.state.p_pos)))
        
    def adversary_reward(self, agent, world):
        # keep the nearest good agents away from the goal
        agent_dist = [np.sqrt(np.sum(np.square(a.state.p_pos - a.goal_a.state.p_pos))) for a in world.agents if
                      not a.adversary]
        pos_rew = min(agent_dist)
        # nearest_agent = world.good_agents[np.argmin(agent_dist)]
        # neg_rew = np.sqrt(np.sum(np.square(nearest_agent.state.p_pos - agent.state.p_pos)))
        neg_rew = np.sqrt(np.sum(np.square(agent.goal_a.state.p_pos - agent.state.p_pos)))
        # neg_rew = sum([np.sqrt(np.sum(np.square(a.state.p_pos - agent.state.p_pos))) for a in world.good_agents])
        return pos_rew - neg_rew

    def observation(self, agent, world): #R: input from environment.py each agent seperately
        # so should return observation for each agent seperately
        # used as input for reward fucntion "so observations are features" 
        # no need for speed difference science spd of ped os known (in single agent we use to account for ped speed)
        # 0 is ped, 1 is bike 
        ped_dist_to_dest = []
        bike_dist_to_dest =[]
        dist_between_ped_bike =[]
        bike_long_dist = []
        bike_lateral_dist = []
        ped_long_dist =[]
        ped_lateral_dist = []
        bike_speed =[]
        ped_speed = []
        angle_difference = [] #theta bike - theta ped 
        bike_ped_speed_diff =[]
        
        #R: here work of input f 1 agent, so get info of other agent from world 
        other_pos = []
        other_vel = []
        other_theta = []
        for other in world.agents: #R: pos other agent - pos of current agent
            if other is agent: continue
            other_pos.append(other.state.p_pos)
            other_vel.append(other.state.p_vel)
            other_theta.append(other.state.p_theta)
            
        if not agent.adversary: #bike 1 
            bike_target = np.zeros(1) ##should get it from agent goal which got from landmark 
            bike_target[0] = np.sqrt(np.sum(np.square(agent.state.p_pos - agent.goal_a.state.p_pos ))) # world.landmarks[1].state.p_pos 
            bike_dist_to_dest.append(bike_target)
            
            dist_between_ped_bike.append(np.sqrt(np.sum(np.square(agent.state.p_pos - other_pos ))))
            bike_speed.append(agent.state.p_vel)
            bike_ped_speed_diff.append(agent.state.p_vel[0] - other_vel[0])
            angle_difference.append(agent.state.p_theta[0] - other_theta[0]) #angle bike - angle ped
            if angle_difference[0][0] < -1*math.pi:
                angle_difference[0][0] =2*math.pi + angle_difference[0][0]
            if angle_difference[0][0] > math.pi:
                angle_difference[0][0] = angle_difference[0][0] - 2*math.pi
            
            #long and lateral dist 
            bike_VX = bike_speed[0][0] * abs(math.sin(agent.state.p_theta)) #abs so +
            bike_VY = bike_speed[0][0] * abs(math.cos(agent.state.p_theta)) # abs so +
            # specify signs of spd components 
            if agent.state.p_theta >= math.pi/2 and agent.state.p_theta <= math.pi: #theta measured from y-axis
                bike_VY = -1* bike_VY
            if agent.state.p_theta >= -1*math.pi/2 and agent.state.p_theta < 0: #theta measured from y-axis
                bike_VX = -1* bike_VX
            if agent.state.p_theta >= -1*math.pi and agent.state.p_theta < -1*math.pi/2: #theta measured from y-axis
                bike_VX = -1* bike_VX
                bike_VY = -1* bike_VY
                       
            delta_bike_X = bike_VX
            delta_bike_Y = bike_VY
            delta_bike = (delta_bike_X**2 + delta_bike_Y**2)**0.5
            delta_bike_ped_X = other_pos[0][0] - agent.state.p_pos[0] #X_ped - X_position
            delta_bike_ped_Y = other_pos[0][1] - agent.state.p_pos[1] #Y_ped - Y_position
            delta_bike_ped = (delta_bike_ped_X**2 + delta_bike_ped_Y**2)**0.5
            
            productunit = (delta_bike_X * delta_bike_ped_X  + delta_bike_Y * delta_bike_ped_Y) / (delta_bike * delta_bike_ped)
            anglefordistance = math.acos(productunit)
            long_dist =  dist_between_ped_bike[0] * math.cos(anglefordistance)
            lateral_dist = abs(dist_between_ped_bike[0] * math.sin(anglefordistance))
            
            if dist_between_ped_bike[0] == 0: ### to avoid nan when ped and cyclists at the same point
                long_dist = 0
                lateral_dist = 0
            
            long = np.zeros(1)
            lateral = np.zeros(1)
            long[0] = long_dist
            lateral[0] = lateral_dist
            bike_long_dist.append(long)
            bike_lateral_dist.append(lateral)
            
            #return: long, lateral, dist to target, spd, angle diff  
            #np.concatenate([agent.state.p_vel] + [agent.goal_a.state.p_pos - agent.state.p_pos] + [agent.color] + entity_pos + entity_color + other_pos)
            return np.concatenate(bike_long_dist + bike_lateral_dist + bike_dist_to_dest + bike_speed + angle_difference + bike_ped_speed_diff)

        else: #ped
            ped_target = np.zeros(1)
            ped_target[0] = np.sqrt(np.sum(np.square(agent.state.p_pos - agent.goal_a.state.p_pos))) #  world.landmarks[0].state.p_pos 
            ped_dist_to_dest.append(ped_target)
            
            dist_between_ped_bike.append(np.sqrt(np.sum(np.square(agent.state.p_pos - other_pos ))))
            ped_speed.append(agent.state.p_vel) 
            bike_ped_speed_diff.append(other_vel[0] - agent.state.p_vel[0]) #spd bike - spd ped 
            angle_difference.append(other_theta[0] - agent.state.p_theta[0]) #angle bike - angle ped 
            if angle_difference[0][0] < -1*math.pi:
                angle_difference[0][0] =2*math.pi + angle_difference[0][0]
            if angle_difference[0][0] > math.pi:
                angle_difference[0][0] = angle_difference[0][0] - 2*math.pi
            
            #long and lateral dist 
            ped_VX = ped_speed[0][0] * abs(math.sin(agent.state.p_theta)) #abs so +
            ped_VY = ped_speed[0][0] * abs(math.cos(agent.state.p_theta)) # abs so +
            # specify signs of spd components 
            if agent.state.p_theta >= math.pi/2 and agent.state.p_theta <= math.pi: #theta measured from y-axis
                ped_VY = -1* ped_VY
            if agent.state.p_theta >= -1*math.pi/2 and agent.state.p_theta < 0: #theta measured from y-axis
                ped_VX = -1* ped_VX
            if agent.state.p_theta >= -1*math.pi and agent.state.p_theta < -1*math.pi/2: #theta measured from y-axis
                ped_VX = -1* ped_VX
                ped_VY = -1* ped_VY
                       
            delta_bike_X = ped_VX
            delta_bike_Y = ped_VY
            delta_bike = (delta_bike_X**2 + delta_bike_Y**2)**0.5
            delta_bike_ped_X = other_pos[0][0] - agent.state.p_pos[0] #x_bike - X_ped
            delta_bike_ped_Y = other_pos[0][1] - agent.state.p_pos[1] #Y_bike - Y_ped
            delta_bike_ped = (delta_bike_ped_X**2 + delta_bike_ped_Y**2)**0.5
            
            productunit = (delta_bike_X * delta_bike_ped_X  + delta_bike_Y * delta_bike_ped_Y) / (delta_bike * delta_bike_ped)
            anglefordistance = math.acos(productunit)
            long_dist =  dist_between_ped_bike[0] * math.cos(anglefordistance)
            lateral_dist = abs(dist_between_ped_bike[0] * math.sin(anglefordistance))
            
            if dist_between_ped_bike[0] == 0: ### to avoid nan when ped and cyclists at the same point
                long_dist = 0
                lateral_dist = 0
                
            long = np.zeros(1)
            lateral = np.zeros(1)
            long[0] = long_dist
            lateral[0] = lateral_dist
            ped_long_dist.append(long)
            ped_lateral_dist.append(lateral)
            
            #return: long, lateral, dist to target, spd, angle diff  
            #np.concatenate([agent.state.p_vel] + [agent.goal_a.state.p_pos - agent.state.p_pos] + [agent.color] + entity_pos + entity_color + other_pos)
            return np.concatenate(ped_long_dist + ped_lateral_dist + ped_dist_to_dest + ped_speed + angle_difference + bike_ped_speed_diff)
            
        
    def done(self, agent, world): #R: later need to modify in case run RL 
        #if world.time >= 500: #original 50 #R: modify this to make it based on final length of traj 
        if world.time == (agent.time_to_done-1):
            return True
        else:
            return False





############################## Shared Space Model continious ##########################
# import numpy as np
# from multiagent.core import World, Agent, Landmark
# from multiagent.scenario import BaseScenario

# import math
# import random
# ### 0 is ped (adversary); agent 1 is cyclist  and same landmarks 
# # add agent max for states (do not ad for x,y), just for speed and theta 
# # state p_pos (x,y), added: p_vel_abs, p_theta 
# class Scenario(BaseScenario):
#     def make_world(self):
#         world = World()
#         # set any world properties first
#         world.dim_c = 2 #R: all scenarios put this 2, do not why ################# may need to put it zero or my it used later in action 
#         num_agents = 2 ## include all with adversary 
#         num_adversaries = 1
#         num_landmarks = 2
#         # add agents
#         world.agents = [Agent() for i in range(num_agents)]
#         for i, agent in enumerate(world.agents):
#             agent.name = 'agent %d' % i
#             agent.collide = False #R: False
#             agent.silent = True #R: cannot send communication signals 
#             agent.max_speed = 7.96 #R: for headon: cyclist 7.96 m/s; 10.1
#             agent.max_theta = math.pi 
#             agent.max_acc = 10.0 #R: m/s2  ### not sure if we need to modify the action output from model since it wuld effect its variance 
#             agent.max_deltatheta = 1.8 #R: rad/s
#             #agent.state.p_theta = np.zeros(1) #R: state var: put them in core 
#             #agent.state.p_vel_abs = np.zeros(1) #R: state var
#             if i < num_adversaries: # for ped 
#                 agent.adversary = True
#                 #agent.initial_mass = 5.0
#                 agent.max_speed = 5.93 # ped R: m/sfor headon: ped: 5.93 m/s; crossing: 6.66
#                 agent.max_theta = math.pi 
#                 agent.max_acc = 5.0 #ped R: m/s2
#                 agent.max_deltatheta = 1.8 #R: rad/s
#             else:
#                 agent.adversary = False
#         # add landmarks
#         world.landmarks = [Landmark() for i in range(num_landmarks)]
#         for i, landmark in enumerate(world.landmarks):
#             landmark.name = 'landmark %d' % i #R: 0 is ped, 1 for bike 
#             landmark.collide = False
#             landmark.movable = False
#         # make initial conditions
#         self.reset_world(world)
#         return world

#     def reset_world(self, world):
#         # random properties for landmarks
#         for i, landmark in enumerate(world.landmarks):
#             #landmark.color = np.array([0.1, 0.1, 0.1])
#             #landmark.color[i + 1] += 0.8
#             landmark.index = i
#         # set goal landmark (simple psh is single landmark, so modify it)
#         #goal = np.random.choice(world.landmarks) #R: can make final position is landmark for each case 
#         for i, agent in enumerate(world.agents):
#             #agent.goal_a = goal
#             agent.goal_a = world.landmarks[i] #0 for ped, 1 for bike 
#             #agent.color = np.array([0.25, 0.25, 0.25])
#             #if agent.adversary:
#                 #agent.color = np.array([0.75, 0.25, 0.25])
#             #else:
#                 #j = goal.index
#                 #agent.color[j + 1] += 0.5
        
#         # put data of all traj ped and cyclist of sahred space in a format to select random from it for initializations,
#         # this should contain ped: initials of : X,Y,theta,V,Xtarget, Ytarget; Cyclist: intials of X,Y,theta,V,Xtarget, Ytarget, Time total of each till done occurs
#         # update previous infos in each agent
        
#         #### activate which case are you working with headon or corssing: data for initilization
#         #headon
#         array_initials =np.loadtxt('/home/bitsafs/Rushdi/RL_multiagent_R/RL_multiagent/rushdi_Final__MA/headon/Evn_InitialS_and_goal/Headon_array_initial_target.txt')
#         # crossing 
#         #array_initials =np.loadtxt('/home/bitsafs/Rushdi/RL_multiagent_R/RL_multiagent/rushdi_Final__MA/crossing/Evn_InitialS_and_goal/crossing_array_initial_target.txt')

#         rn_len = len(array_initials) #229 for head on 
#         rn = random.randint(0,rn_len-1)
#         #rn = 0 # just do debugging 
         
#         for i, agent in enumerate(world.agents):
#             if i == 0: #ped
#                 agent.state.p_pos = np.zeros(world.dim_p) #np.random.uniform(-1, +1, world.dim_p)
#                 agent.state.p_pos[0] = array_initials[rn][0]
#                 agent.state.p_pos[1] = array_initials[rn][1]
                
#                 agent.state.p_theta = np.zeros(1) 
#                 agent.state.p_theta[0] =  array_initials[rn][2] 
                
#                 agent.state.p_vel = np.ones(1)
#                 agent.state.p_vel[0] = array_initials[rn][3]
#                 agent.time_to_done = array_initials[rn][12]
#                 agent.traj_id = rn+1
                
#             if i == 1: #bike
#                 agent.state.p_pos = np.zeros(world.dim_p) #np.random.uniform(-1, +1, world.dim_p)
#                 agent.state.p_pos[0] = array_initials[rn][6]
#                 agent.state.p_pos[1] = array_initials[rn][7]
                
#                 agent.state.p_theta = np.zeros(1) 
#                 agent.state.p_theta[0] =  array_initials[rn][8] 
                
#                 agent.state.p_vel = np.ones(1)
#                 agent.state.p_vel[0] = array_initials[rn][9]
#                 agent.time_to_done = array_initials[rn][12]
#                 agent.traj_id = rn+1
                 
#         for i, landmark in enumerate(world.landmarks):
#             if  i ==0:
#                 landmark.state.p_pos = np.ones(world.dim_p)
#                 landmark.state.p_pos[0] = array_initials[rn][4]
#                 landmark.state.p_pos[1] = array_initials[rn][5]
#             if  i ==1:
#                 landmark.state.p_pos = np.ones(world.dim_p)
#                 landmark.state.p_pos[0] = array_initials[rn][10]
#                 landmark.state.p_pos[1] = array_initials[rn][11]
    
        
#         # # set random initial states (R: need to modify them later in case will se them to generate traj)
#         # for agent in world.agents: ##R: make restart based on initial traj points 
#         #     agent.state.p_pos = np.zeros(world.dim_p) #np.random.uniform(-1, +1, world.dim_p)
#         #     agent.state.p_vel = np.ones(1)#np.zeros(world.dim_p)
#         #     #agent.state.c = np.zeros(world.dim_c)
#         #     agent.state.p_theta = np.zeros(1) #R: state var
#         #     #agent.state.p_vel_abs =  np.zeros(1) #R: state var 
         

#     def reward(self, agent, world):
#         # Agents are rewarded based on minimum agent distance to each landmark
#         return self.adversary_reward(agent, world) if agent.adversary else self.agent_reward(agent, world)

#     def agent_reward(self, agent, world): #R: bike reward
#         # the distance to the goal #R: set reward from discriminator 
#         return -np.sqrt(np.sum(np.square(agent.state.p_pos - agent.goal_a.state.p_pos)))
        
#     def adversary_reward(self, agent, world):
#         # keep the nearest good agents away from the goal
#         agent_dist = [np.sqrt(np.sum(np.square(a.state.p_pos - a.goal_a.state.p_pos))) for a in world.agents if
#                       not a.adversary]
#         pos_rew = min(agent_dist)
#         # nearest_agent = world.good_agents[np.argmin(agent_dist)]
#         # neg_rew = np.sqrt(np.sum(np.square(nearest_agent.state.p_pos - agent.state.p_pos)))
#         neg_rew = np.sqrt(np.sum(np.square(agent.goal_a.state.p_pos - agent.state.p_pos)))
#         # neg_rew = sum([np.sqrt(np.sum(np.square(a.state.p_pos - agent.state.p_pos))) for a in world.good_agents])
#         return pos_rew - neg_rew

#     def observation(self, agent, world): #R: input from environment.py each agent seperately
#         # so should return observation for each agent seperately
#         # used as input for reward fucntion "so observations are features" 
#         # no need for speed difference science spd of ped os known (in single agent we use to account for ped speed)
#         # 0 is ped, 1 is bike 
#         ped_dist_to_dest = []
#         bike_dist_to_dest =[]
#         dist_between_ped_bike =[]
#         bike_long_dist = []
#         bike_lateral_dist = []
#         ped_long_dist =[]
#         ped_lateral_dist = []
#         bike_speed =[]
#         ped_speed = []
#         angle_difference = [] #theta bike - theta ped 
#         bike_ped_speed_diff =[]
        
#         #R: here work of input f 1 agent, so get info of other agent from world 
#         other_pos = []
#         other_vel = []
#         other_theta = []
#         for other in world.agents: #R: pos other agent - pos of current agent
#             if other is agent: continue
#             other_pos.append(other.state.p_pos)
#             other_vel.append(other.state.p_vel)
#             other_theta.append(other.state.p_theta)
            
#         if not agent.adversary: #bike 1 
#             bike_target = np.zeros(1) ##should get it from agent goal which got from landmark 
#             bike_target[0] = np.sqrt(np.sum(np.square(agent.state.p_pos - agent.goal_a.state.p_pos ))) # world.landmarks[1].state.p_pos 
#             bike_dist_to_dest.append(bike_target)
            
#             dist_between_ped_bike.append(np.sqrt(np.sum(np.square(agent.state.p_pos - other_pos ))))
#             bike_speed.append(agent.state.p_vel)
#             bike_ped_speed_diff.append(agent.state.p_vel[0] - other_vel[0])
#             angle_difference.append(agent.state.p_theta[0] - other_theta[0]) #angle bike - angle ped
#             if angle_difference[0][0] < -1*math.pi:
#                 angle_difference[0][0] =2*math.pi + angle_difference[0][0]
#             if angle_difference[0][0] > math.pi:
#                 angle_difference[0][0] = angle_difference[0][0] - 2*math.pi
            
#             #long and lateral dist 
#             bike_VX = bike_speed[0][0] * abs(math.sin(agent.state.p_theta)) #abs so +
#             bike_VY = bike_speed[0][0] * abs(math.cos(agent.state.p_theta)) # abs so +
#             # specify signs of spd components 
#             if agent.state.p_theta >= math.pi/2 and agent.state.p_theta <= math.pi: #theta measured from y-axis
#                 bike_VY = -1* bike_VY
#             if agent.state.p_theta >= -1*math.pi/2 and agent.state.p_theta < 0: #theta measured from y-axis
#                 bike_VX = -1* bike_VX
#             if agent.state.p_theta >= -1*math.pi and agent.state.p_theta < -1*math.pi/2: #theta measured from y-axis
#                 bike_VX = -1* bike_VX
#                 bike_VY = -1* bike_VY
                       
#             delta_bike_X = bike_VX
#             delta_bike_Y = bike_VY
#             delta_bike = (delta_bike_X**2 + delta_bike_Y**2)**0.5
#             delta_bike_ped_X = other_pos[0][0] - agent.state.p_pos[0] #X_ped - X_position
#             delta_bike_ped_Y = other_pos[0][1] - agent.state.p_pos[1] #Y_ped - Y_position
#             delta_bike_ped = (delta_bike_ped_X**2 + delta_bike_ped_Y**2)**0.5
            
#             productunit = (delta_bike_X * delta_bike_ped_X  + delta_bike_Y * delta_bike_ped_Y) / (delta_bike * delta_bike_ped)
#             anglefordistance = math.acos(productunit)
#             long_dist =  dist_between_ped_bike[0] * math.cos(anglefordistance)
#             lateral_dist = abs(dist_between_ped_bike[0] * math.sin(anglefordistance))
            
#             if dist_between_ped_bike[0] == 0: ### to avoid nan when ped and cyclists at the same point
#                 long_dist = 0
#                 lateral_dist = 0
            
#             long = np.zeros(1)
#             lateral = np.zeros(1)
#             long[0] = long_dist
#             lateral[0] = lateral_dist
#             bike_long_dist.append(long)
#             bike_lateral_dist.append(lateral)
            
#             #return: long, lateral, dist to target, spd, angle diff  
#             #np.concatenate([agent.state.p_vel] + [agent.goal_a.state.p_pos - agent.state.p_pos] + [agent.color] + entity_pos + entity_color + other_pos)
#             return np.concatenate(bike_long_dist + bike_lateral_dist + bike_dist_to_dest + bike_speed + angle_difference + bike_ped_speed_diff)

#         else: #ped
#             ped_target = np.zeros(1)
#             ped_target[0] = np.sqrt(np.sum(np.square(agent.state.p_pos - agent.goal_a.state.p_pos))) #  world.landmarks[0].state.p_pos 
#             ped_dist_to_dest.append(ped_target)
            
#             dist_between_ped_bike.append(np.sqrt(np.sum(np.square(agent.state.p_pos - other_pos ))))
#             ped_speed.append(agent.state.p_vel) 
#             bike_ped_speed_diff.append(other_vel[0] - agent.state.p_vel[0]) #spd bike - spd ped 
#             angle_difference.append(other_theta[0] - agent.state.p_theta[0]) #angle bike - angle ped 
#             if angle_difference[0][0] < -1*math.pi:
#                 angle_difference[0][0] =2*math.pi + angle_difference[0][0]
#             if angle_difference[0][0] > math.pi:
#                 angle_difference[0][0] = angle_difference[0][0] - 2*math.pi
            
#             #long and lateral dist 
#             ped_VX = ped_speed[0][0] * abs(math.sin(agent.state.p_theta)) #abs so +
#             ped_VY = ped_speed[0][0] * abs(math.cos(agent.state.p_theta)) # abs so +
#             # specify signs of spd components 
#             if agent.state.p_theta >= math.pi/2 and agent.state.p_theta <= math.pi: #theta measured from y-axis
#                 ped_VY = -1* ped_VY
#             if agent.state.p_theta >= -1*math.pi/2 and agent.state.p_theta < 0: #theta measured from y-axis
#                 ped_VX = -1* ped_VX
#             if agent.state.p_theta >= -1*math.pi and agent.state.p_theta < -1*math.pi/2: #theta measured from y-axis
#                 ped_VX = -1* ped_VX
#                 ped_VY = -1* ped_VY
                       
#             delta_bike_X = ped_VX
#             delta_bike_Y = ped_VY
#             delta_bike = (delta_bike_X**2 + delta_bike_Y**2)**0.5
#             delta_bike_ped_X = other_pos[0][0] - agent.state.p_pos[0] #x_bike - X_ped
#             delta_bike_ped_Y = other_pos[0][1] - agent.state.p_pos[1] #Y_bike - Y_ped
#             delta_bike_ped = (delta_bike_ped_X**2 + delta_bike_ped_Y**2)**0.5
            
#             productunit = (delta_bike_X * delta_bike_ped_X  + delta_bike_Y * delta_bike_ped_Y) / (delta_bike * delta_bike_ped)
#             anglefordistance = math.acos(productunit)
#             long_dist =  dist_between_ped_bike[0] * math.cos(anglefordistance)
#             lateral_dist = abs(dist_between_ped_bike[0] * math.sin(anglefordistance))
            
#             if dist_between_ped_bike[0] == 0: ### to avoid nan when ped and cyclists at the same point
#                 long_dist = 0
#                 lateral_dist = 0
                
#             long = np.zeros(1)
#             lateral = np.zeros(1)
#             long[0] = long_dist
#             lateral[0] = lateral_dist
#             ped_long_dist.append(long)
#             ped_lateral_dist.append(lateral)
            
#             #return: long, lateral, dist to target, spd, angle diff  
#             #np.concatenate([agent.state.p_vel] + [agent.goal_a.state.p_pos - agent.state.p_pos] + [agent.color] + entity_pos + entity_color + other_pos)
#             return np.concatenate(ped_long_dist + ped_lateral_dist + ped_dist_to_dest + ped_speed + angle_difference + bike_ped_speed_diff)
            
        
#     def done(self, agent, world): #R: later need to modify in case run RL 
#         #if world.time >= 500: #original 50 #R: modify this to make it based on final length of traj 
#         if world.time == (agent.time_to_done-1):
#             return True
#         else:
#             return False

# ################### original simple_push ######################## 
# import numpy as np
# from multiagent.core import World, Agent, Landmark
# from multiagent.scenario import BaseScenario

# class Scenario(BaseScenario):
#     def make_world(self):
#         world = World()
#         # set any world properties first
#         world.dim_c = 2
#         num_agents = 2 ## include all with adversary 
#         num_adversaries = 1
#         num_landmarks = 2
#         # add agents
#         world.agents = [Agent() for i in range(num_agents)]
#         for i, agent in enumerate(world.agents):
#             agent.name = 'agent %d' % i
#             agent.collide = True #R: False
#             agent.silent = True #R: cannot send communication signals 
#             agent.max_speed = 2.0 #R: specify for each agent 
#             if i < num_adversaries:
#                 agent.adversary = True
#                 agent.initial_mass = 5.0
#             else:
#                 agent.adversary = False
#         # add landmarks
#         world.landmarks = [Landmark() for i in range(num_landmarks)]
#         for i, landmark in enumerate(world.landmarks):
#             landmark.name = 'landmark %d' % i
#             landmark.collide = False
#             landmark.movable = False
#         # make initial conditions
#         self.reset_world(world)
#         return world

#     def reset_world(self, world):
#         # random properties for landmarks
#         for i, landmark in enumerate(world.landmarks):
#             landmark.color = np.array([0.1, 0.1, 0.1])
#             landmark.color[i + 1] += 0.8
#             landmark.index = i
#         # set goal landmark
#         goal = np.random.choice(world.landmarks) #R: can make final position is landmark for each case 
#         for i, agent in enumerate(world.agents):
#             agent.goal_a = goal
#             agent.color = np.array([0.25, 0.25, 0.25])
#             if agent.adversary:
#                 agent.color = np.array([0.75, 0.25, 0.25])
#             else:
#                 j = goal.index
#                 agent.color[j + 1] += 0.5
#         # set random initial states
#         for agent in world.agents: ##R: make restart based on initial traj points 
#             agent.state.p_pos = np.random.uniform(-1, +1, world.dim_p)
#             agent.state.p_vel = np.zeros(world.dim_p)
#             agent.state.c = np.zeros(world.dim_c)
#         for i, landmark in enumerate(world.landmarks):
#             landmark.state.p_pos = np.random.uniform(-0.8, +0.8, world.dim_p)
#             landmark.state.p_vel = np.zeros(world.dim_p)

#     def reward(self, agent, world):
#         # Agents are rewarded based on minimum agent distance to each landmark
#         return self.adversary_reward(agent, world) if agent.adversary else self.agent_reward(agent, world)

#     def agent_reward(self, agent, world):
#         # the distance to the goal
#         return -np.sqrt(np.sum(np.square(agent.state.p_pos - agent.goal_a.state.p_pos)))

#     def adversary_reward(self, agent, world):
#         # keep the nearest good agents away from the goal
#         agent_dist = [np.sqrt(np.sum(np.square(a.state.p_pos - a.goal_a.state.p_pos))) for a in world.agents if
#                       not a.adversary]
#         pos_rew = min(agent_dist)
#         # nearest_agent = world.good_agents[np.argmin(agent_dist)]
#         # neg_rew = np.sqrt(np.sum(np.square(nearest_agent.state.p_pos - agent.state.p_pos)))
#         neg_rew = np.sqrt(np.sum(np.square(agent.goal_a.state.p_pos - agent.state.p_pos)))
#         # neg_rew = sum([np.sqrt(np.sum(np.square(a.state.p_pos - agent.state.p_pos))) for a in world.good_agents])
#         return pos_rew - neg_rew

#     def observation(self, agent, world): #R: check how these infos are used in MA-AIRL
#         # get positions of all entities in this agent's reference frame
#         entity_pos = []
#         for entity in world.landmarks:  # world.entities:
#             entity_pos.append(entity.state.p_pos - agent.state.p_pos)
#         # entity colors
#         entity_color = []
#         for entity in world.landmarks:  # world.entities:
#             entity_color.append(entity.color)
#         # communication of all other agents
#         comm = []
#         other_pos = []
#         for other in world.agents:
#             if other is agent: continue
#             comm.append(other.state.c)
#             other_pos.append(other.state.p_pos - agent.state.p_pos)
#         if not agent.adversary:
#             return np.concatenate([agent.state.p_vel] + [agent.goal_a.state.p_pos - agent.state.p_pos] + [agent.color] + entity_pos + entity_color + other_pos)
#         else:
#             #other_pos = list(reversed(other_pos)) if random.uniform(0,1) > 0.5 else other_pos  # randomize position of other agents in adversary network
#             return np.concatenate([agent.state.p_vel] + [agent.goal_a.state.p_pos - agent.state.p_pos] + entity_pos + other_pos)

#     def done(self, agent, world):
#         if world.time >= 50: #R: modify this to make it based on final length of traj 
#             return True
#         else:
#             return False
